package laby;
import java.util.*;

public class Plateau {
	public Case lesCases[];
	public int n, m;
	public int taille;
	public int nbrMurCasse = 0;
	
	public Plateau (int m, int n){
		this.m = m;
		this.n = n;
		this.taille = m*n;
		this.lesCases = new Case[taille];
		for (int i = 0 ; i < taille ; i++){
			lesCases[i] = new Case(i , i , this);
			
		}
	}
	
	

	public Case getCaseXY(int x, int y){
		return this.lesCases[this.n * y + x];
	}
	
	public Case getCaseCote(Case laCase, int dir){
		int x, y;
		System.out.println("indice : " + laCase.getIndice() + "direction : "+ dir);
		x = laCase.calculerX();
		System.out.println("x : " + x);

		y = laCase.calculerY();		
		System.out.println("y : " + y);

		if(dir == 0){
			y--;}
		else if (dir == 1){
			x++;}
		else if (dir == 2){
			y++;}
		else if (dir == 3){
			x--;}
		return getCaseXY(x, y);
		
		
	}
	
	
	public Case getRandomCaseCote(Case laCase){
		int i = random(3);
		return getCaseCote(laCase, i);
		
	}
	
	
	public int random(int n){ //renvoie un nbr entre 0 et n
		//Random rand = new Random();
		//int nombreAleatoire = rand.nextInt(n);
		//return nombreAleatoire;
		return ((int)(Math.random()*n));
	}
	public int random(int min, int max){
		
		return ((int)(min+(Math.random()*(max - min))));
	}
	
	
	public void casserMur(Case laCase1, Case laCase2, int dir){
		laCase1.setMurLibre(dir);
		if(dir < 2)
			{dir = dir + 2;
		}else
			{dir = dir - 2;
		}
		laCase2.setMurLibre(dir);
		nbrMurCasse ++;
	}
	
	public void initialiser(){
		ArrayList<Integer> historique= new ArrayList<Integer>();
		int indiceFusion = random(this.taille);
		
		boolean test = false;
		
		System.out.println("ok1");
		System.out.println(indiceFusion);
		while (nbrMurCasse != m * n - 1){
			
			while(!test){
				indiceFusion = random(this.taille);
				/*while(historique.contains(indiceFusion) ){
					indiceFusion = random(this.taille);
					System.out.println("ok2");
				}*/
				test = fusionner(indiceFusion);
			
		}
		historique.add(indiceFusion);
		System.out.println("mur cr�� : "+historique.size());
		test = false;
		System.out.println("ok c'est finis");
		}
	}
	
	public boolean fusionner(int i){
		System.out.println("�a passe la au moins");
		Case laCase = this.lesCases[i];
		
		int alea = random(4);
		if (i%n == 0){
			alea = random(3);
		}else if (i%n == n - 1){
			while (alea == 1){
				alea = random(4);
			}
		}else if (lesCases[i].calculerY()== 0){
			while (alea == 0){
				alea = random(4);
			}
		}else if (lesCases[i].calculerY()== m-1){
			while (alea == 2){
				alea = random(4);
			}
		}
		
		if(i == 0){
			alea = random(1, 3);
		}else if(i == n - 1){
			alea = random(2, 4);
		}else if(i == taille - 1){
			while(alea == 1 || alea == 2){
				alea = random(4);
			}
		}else if (i == taille - n){
			alea = random(0, 2);
		}
		
		Case laCaseCote = getCaseCote(laCase, alea);
		if(laCase.getId() == laCaseCote.getId()){
			return false;
		}
			int temp = laCaseCote.getId();
			laCaseCote.setId(laCase.getId());
			casserMur(laCase, laCaseCote, alea);
			for (int c = 0 ; c < this.taille ; c ++){
				if (lesCases[c].getId()== temp){
					lesCases[c].setId(laCase.getId());	
				}
			}
			return true;
	}
	
	
}
