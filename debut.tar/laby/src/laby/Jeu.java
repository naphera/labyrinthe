package laby;

import java.util.Scanner;

public class Jeu {
	private Plateau plateau;
	private Personnage personnage;
	private int xgagnant;
	private int ygagnant;
	private boolean victoire;

	//CONSTRUCTEUR
	public Jeu (Plateau plat, Personnage perso) {
		this.plateau = plat;
		this.personnage = perso;
		this.victoire = false;
		this.xgagnant = plat.m-1;
		this.ygagnant = plat.n-1;
	}

	//INITIALISERS
	public void initialiser() {
		plateau.initialiser();
		
	}
	//DEPLACER LE PERSONNAGE
	public boolean deplacer(int a) {

		//DEPLACER VERS LE HAUT / a=0
		if(a==0) {
			if(this.plateau.getCaseXY( this.personnage.getX(),this.personnage.getY() ).getMur(0) == false){
				this.personnage.haut();
				return true;
			}else{
				return false;
			}
				
		}

		//DEPLACER VERS LA DROITE / a=1
		if(a==1) {
			if(this.plateau.getCaseXY( this.personnage.getX(),this.personnage.getY() ).getMur(1) == false){
				this.personnage.droite();
				return true;
			}else{
				return false;
			}
		}

		//DEPLACER VERS LE BAS / a=2
		if(a==2) {
			if(this.plateau.getCaseXY( this.personnage.getX(),this.personnage.getY() ).getMur(2) == false){
				this.personnage.bas();
				return true;
			}else{
				return false;
			}
		}

		//DEPLACER VERS LA GAUCHE / a=3
		if(a==3) {
			if(this.plateau.getCaseXY( this.personnage.getX(),this.personnage.getY() ).getMur(3) == false){
				this.personnage.gauche();
			return true;
		}else{
			return false;
		}

		}
		return false;
	}
	//ARRETER LA PARTIE QUAND LE PERSONNAGE EST A LA COORDONNE FINALE / METTRE THIS.VICTOIRE A TRUE
	public void gagner() {
		if(this.personnage.getX() == this.xgagnant) {
			if(this.personnage.getY() == this.ygagnant) {
				this.victoire = true;
			}
		}
	}

	//METHODE QUI PERMET DE JOUER AU JEU
	public void jouer() {
		int a = 0;
		boolean test;
		while(this.victoire == false) {
			
			Scanner sc = new Scanner(System.in);
			a = sc.nextInt();
			
			test = deplacer(a);
			while (!test){
				System.out.println("deplacement invalide");
				
				a = sc.nextInt();
				
				test = deplacer(a);
			}
			
			gagner();
		}
		System.out.println("You Win !");
	}

}
