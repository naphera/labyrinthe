package laby;


import java.io.*;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Test {
	
	public static void main(String[] args) throws IOException{
		System.setProperty( "file.encoding", "UTF-8" );
		Plateau plateau;
		for(int i = 0 ; i < 1 ; i ++){
		plateau = new Plateau(5, 5);
		System.out.println("plateau cr��");
		Personnage perso = new Personnage("abel");
		Jeu jeu = new Jeu(plateau, perso);
		jeu.initialiser();
		jeu.jouer();
		
		
	/*	
		System.out.println("plateau init \n \n \n");
		String repr = "";
		for (i = 0 ; i < plateau.n; i++){
			for(int j = 0 ; j < plateau.m ; j++){
				repr += plateau.getCaseXY(j, i);
			}
			repr += "\n";
		}
		System.out.println(repr);
		
	/*	String str2 = new String(repr.getBytes(),Charset.forName("UTF-8"));
		
		
		BufferedWriter out = new BufferedWriter(new FileWriter("d://cours/projet s-2/test_laby.txt"));
		try {
			out.write(str2);
		
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*
		SimpleDateFormat filePattern = new SimpleDateFormat("ddMMyyyy_HHmm");
        String filename=filePattern.format(new Date()) + ".txt";
        //ouvrir le fichier
        File file = new File("d://cours/projet s-2/"+filename);
        try {
            PrintStream printStream = new PrintStream(file);
            System.setOut(printStream);
            
            System.out.println("Tout ce qui apparait dans la console est repris dans le fichier");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }*/
		
		}
	}
}
