package laby;

public class Case {

	private int id, indice;
	private boolean mur[];
	private boolean visited;
	private boolean perso = false;
	private Plateau plateau;
	
	public Case(int id, int indice, Plateau plateau){
		this.indice = indice;
		this.id = id ;
		this.plateau = plateau;
		this.mur = new boolean[4];
		for(int i = 0 ; i < 4 ; i++){
			this.mur[i] = true;
		}
	}
	
	public int calculerX(){
		return this.indice%plateau.n;
	}
	
	public int calculerY(){
		return this.indice/plateau.n;
	}
	
	
	public void setMurLibre(int indice){
		this.mur[indice] = false;
	}
	
	public void setVisited(boolean bool){
		this.visited = bool;
		
	}
	
	public int getId(){
		return this.id;
	}
	
	public void setId(int i){
		this.id = i;
	}
	
	public int getIndice(){
		return this.indice;
	}
	
	public boolean getMur(int i){
		return mur[i];
	}
	
	
	public String toString(){
		String tmp="";

		if (mur[0] == true && mur[1] == true && mur[2] == true && mur[3] == true){
			return "";
		}else if (mur[0] == false && mur[1] == false && mur[2] == true && mur[3] == true){
			return "";
		}else if (mur[0] == false && mur[1] == true && mur[2] == true && mur[3] == false){
			return"㇘";
		}else if (mur[0] == true && mur[1] == false && mur[2] == false && mur[3] == true){
			return "厂";	
		}else if (mur[0] == true && mur[1] == true && mur[2] == false && mur[3] == false){
			return "㇕";
		}else if (mur[0] == true && mur[1] == false && mur[2] == true && mur[3] == false){
			return "⼆";
		}else if (mur[0] == false && mur[1] == true && mur[2] == false && mur[3] == true){
			return "⇅";
			
		}else if (mur[0] == true && mur[1] == false && mur[2] == true && mur[3] == true){
			return "⼕";
		}else if (mur[0] == false && mur[1] == true && mur[2] == true && mur[3] == true){
			return "⼐";
		}else if (mur[0] == true && mur[1] == true && mur[2] == true && mur[3] == false){
			return "コ";
		}else if (mur[0] == true && mur[1] == true && mur[2] == false && mur[3] == true){
			return "⨅";
		}else if (mur[0] == true && mur[1] == false && mur[2] == false && mur[3] == false){
			return "▔";
		}else if (mur[0] == false && mur[1] == false && mur[2] == true && mur[3] == false){
			return "_";
		}else if (mur[0] == false && mur[1] == true && mur[2] == false && mur[3] == false){
			return "▕";
		}else if (mur[0] == false && mur[1] == false && mur[2] == false && mur[3] == true){
			return "▏  ";
		}else if (mur[0] == false && mur[1] == false && mur[2] == false && mur[3] == false){
			return "O";
		}else{
			return "bug";
			
	}
	
}
}
