package laby;

public class Personnage {
	private String pseudo;
	private int x;
	private int y;

 //CONSTRUCTEUR
 public Personnage(String pseudo_pers){
	this.pseudo = pseudo_pers;
	this.x = 0;
	this.y = 0;
	}

  //LES METHODES GET()
  public int getX() {
    return this.x;
  }
  public int getY() {
    return this.y;
  }
  public String getPseudo() {
    return this.pseudo;
  }

  //LES METHODES DE DEPLACEMENT
  public void gauche() {
    this.x--;
  }

  public void droite() {
    this.x++;
  }

  public void haut(){
    this.y--;
  }

  public void bas(){
    this.y++;
  }



}
